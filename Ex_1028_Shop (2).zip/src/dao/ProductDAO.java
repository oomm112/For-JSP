package dao;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;

import service.MyBatisConnector;
import vo.ProductVO;

public class ProductDAO {
	// single-ton pattern: 
	// 객체1개만생성해서 지속적으로 서비스하자
	static ProductDAO single = null;

	public static ProductDAO getInstance() {
		//생성되지 않았으면 생성
		if (single == null)
			single = new ProductDAO();
		//생성된 객체정보를 반환
		return single;
	}
	
	SqlSessionFactory factory;
	
	public ProductDAO() {
		factory = MyBatisConnector.getInstance().getFactory();
	}
	
	public List<ProductVO> select(String category){
		
		List<ProductVO> list = null;
		SqlSession sqlSession = factory.openSession();
		
		list = sqlSession.selectList("pro.product_list", category);
		
		sqlSession.close();
		return list;
	}
	
	public ProductVO selectone(int idx){
		
		ProductVO vo = null;
		SqlSession sqlSession = factory.openSession();
		
		vo = sqlSession.selectOne("pro.product_list_one", idx);
		
		sqlSession.close();
		return vo;
	}
	
	//상품등록
	public int insert(ProductVO vo) {
		
		SqlSession sqlSession = factory.openSession(true);			//openSession()안에 true를 넣으면 오토커밋이 된다.
		int cnt = sqlSession.insert("pro.product_insert", vo);
		sqlSession.close();
		
		return cnt;
	}
	
	
}

package vo;

import java.sql.Date;

public class SawonVO {
	private int sabun;
	private String saname;
	private String sagen;
	private int deptno;
	private String sajob;
	private Date sahire;
	private int samgr;
	private int sapay;
	
	public int getSabun() {
		return sabun;
	}
	public void setSabun(int sabun) {
		this.sabun = sabun;
	}
	public String getSaname() {
		return saname;
	}
	public void setSaname(String saname) {
		this.saname = saname;
	}
	public String getSagen() {
		return sagen;
	}
	public void setSagen(String sagen) {
		this.sagen = sagen;
	}
	public int getDeptno() {
		return deptno;
	}
	public void setDeptno(int deptno) {
		this.deptno = deptno;
	}
	public String getSajob() {
		return sajob;
	}
	public void setSajob(String sajob) {
		this.sajob = sajob;
	}
	public int getSamgr() {
		return samgr;
	}
	public void setSamgr(int samgr) {
		this.samgr = samgr;
	}
	public int getSapay() {
		return sapay;
	}
	public void setSapay(int sapay) {
		this.sapay = sapay;
	}
	public Date getSahire() {
		return sahire;
	}
	public void setSahire(Date sahire) {
		this.sahire = sahire;
	}
	
	
}

package action;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.BoardDAO;
import vo.BoardVO;

/**
 * Servlet implementation class BoardDeleteAction
 */
@WebServlet("/board/del.do")
public class BoardDeleteAction extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String pwd = request.getParameter("pwd");
		int idx = Integer.parseInt(request.getParameter("idx"));
		
		BoardDAO dao = BoardDAO.getInstance();
		
		//삭제가 가능한지 확인
		BoardVO baseVO = dao.selectOne(idx, pwd);
		
		String resultStr = "";
		String result = "no";
		
		//삭제가 불가능한 글이라면	(JSON 형식으로 넘김)
		if (baseVO == null) {
			resultStr = String.format("[{'res':'%s'}]", result);
			response.getWriter().print(resultStr);
			return;
		}
		
		//삭제가 가능한 게시글일 경우, 지워진 것 처럼 보이도록 내용을 수정
		baseVO.setSubject("삭제된 게시물 입니다");
		baseVO.setName("unknown");
		
		//삭제가 된것처럼 업데이트를 수행
		int res = dao.del_update(baseVO);
		
		if (res == 1) {
			result = "yes";
		}
		resultStr = String.format("[{'res':'%s'}]", result);
		response.getWriter().print(resultStr);
	}

}

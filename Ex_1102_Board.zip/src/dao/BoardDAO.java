package dao;

import java.util.HashMap;
import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;

import service.MyBatisConnector;
import vo.BoardVO;

public class BoardDAO {
	// single-ton pattern: 
	// 객체1개만생성해서 지속적으로 서비스하자
	static BoardDAO single = null;

	public static BoardDAO getInstance() {
		//생성되지 않았으면 생성
		if (single == null)
			single = new BoardDAO();
		//생성된 객체정보를 반환
		return single;
	}
	
	SqlSessionFactory factory;
	
	public BoardDAO() {
		factory = MyBatisConnector.getInstance().getFactory();
	}
	
	public List<BoardVO> selectList(){
		
		List<BoardVO> list = null;
		SqlSession sql = factory.openSession();
		
		list = sql.selectList("board.board_list");
		
		sql.close();
		return list;
	}
	
	//페이지별 게시물 조회
	public List<BoardVO> selectList(HashMap<String, Integer> map){
		
		List<BoardVO> list = null;
		SqlSession sql = factory.openSession();
		
		list = sql.selectList("board.board_list_condition", map);
		
		sql.close();
		return list;
	}
	
	public int insert(BoardVO vo) {
		SqlSession sql = factory.openSession(true);
		int res = sql.insert("board.board_insert", vo);
		
		sql.close();
		return res;
	}
	
	public BoardVO selectOne(int idx) {
		BoardVO vo = null;
		SqlSession sql = factory.openSession();
		vo = sql.selectOne("board.board_selectone", idx);
		
		sql.close();
		return vo;
	}
	
	public int update_readhit(int idx) {
		SqlSession sql = factory.openSession(true);
		int res = sql.update("board.board_update_readhit", idx);
		
		sql.close();
		return res;
	}
	
	//스텝 수정
	public int update_step(BoardVO baseVO) {
		SqlSession sql = factory.openSession(true);
		int res = sql.update("board.board_update_step", baseVO);
		
		sql.close();
		return res;
	}
	
	public int reply(BoardVO vo) {
		SqlSession sql = factory.openSession(true);
		int res = sql.insert("board.board_reply", vo);
		
		sql.close();
		return res;		
	}
	
	public BoardVO selectOne(int idx, String pwd) {
		BoardVO vo = null;
		SqlSession sql = factory.openSession();
		HashMap<String, Object> map = new HashMap<>();
		map.put("pwd", pwd);
		map.put("idx", idx);
		
		vo = sql.selectOne("board.idx_pwd", map);
		
		sql.close();
		return vo;
	}
	
	public int del_update(BoardVO baseVO) {
		SqlSession sql = factory.openSession(true);
		int res = sql.update("board.del_update", baseVO);
		
		sql.close();
		return res;
	}
	
	public int getRowTotal() {
		SqlSession sql = factory.openSession();
		int raw = sql.selectOne("board.board_count");
		
		sql.close();
		return raw;
	}
}

package dao;

import java.util.HashMap;
import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;

import service.MyBatisConnector;
import vo.CartVO;

public class CartDAO {
	// single-ton pattern: 
	// 객체1개만생성해서 지속적으로 서비스하자
	static CartDAO single = null;

	public static CartDAO getInstance() {
		//생성되지 않았으면 생성
		if (single == null)
			single = new CartDAO();
		//생성된 객체정보를 반환
		return single;
	}
	
	SqlSessionFactory factory;
	public CartDAO() {
		factory = MyBatisConnector.getInstance().getFactory();
	}
	
	//회원별 장바구니 목록 조회
	public List<CartVO> select(int m_idx){
		
		List<CartVO> list = null;
		SqlSession sqlSession = factory.openSession();
		
		try {
			list = sqlSession.selectList("cart.cart_list", m_idx);
			
		} catch (Exception e) {
			System.out.println("aa:" + list);
			e.printStackTrace();
		}
		sqlSession.close();
		
		return list;
	}
	
	//회원별 장바구니 상품의 총계
	public int selectTotalAmount( int m_idx ) {
		
		SqlSession sqlSession = factory.openSession();
		int total = sqlSession.selectOne("cart.total_amount", m_idx);
		sqlSession.close();
		
		return total;
	}
	
	//상품수량 , 번호, 유저idx를 통해 바꾸고자 하는 수량을 업데이트 한다
	
	public int update_cnt(int c_idx, int c_cnt, int m_idx) {
		
		SqlSession sql = factory.openSession(true);
		
		HashMap<String, Integer> map = new HashMap<String, Integer>();
		map.put("c_idx", c_idx);
		map.put("c_cnt", c_cnt);
		map.put("m_idx", m_idx);
		
		int res = sql.update("cart.cart_cnt_update", map);		
		
		sql.close();
		return res;
	}
	
	public int delete(int c_idx, int m_idx) {
		
		SqlSession sql = factory.openSession(true);
		HashMap<String, Integer> map = new HashMap<String, Integer>();
		map.put("c_idx", c_idx);
		map.put("m_idx", m_idx);
		
		int res = sql.delete("cart.cart_delete", map);

		sql.close();
		return res;
	}
	
}



































